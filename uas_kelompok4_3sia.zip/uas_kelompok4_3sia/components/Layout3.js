import React, { useState, useEffect } from 'react';
import {
  Text,
  View,
  StyleSheet,
  Image,
  TouchableOpacity,
  FlatList,
} from 'react-native';
import Constants from 'expo-constants';
import axios from 'axios';
// You can import from local files
import AssetsExample from './AssetExample';

// or any pure javascript modules available in npm
import { Card } from 'react-native-paper';
import { Ionicons, Feather } from '@expo/vector-icons';

export default function Layout3({ route, navigation }) {
  const [kursi, setKursi] = useState([]);
  const [nomorkursi, setNomorkursi] = useState('');
  const getKursi = async () => {
    try {
      const dataIsi = await axios.get(
        'https://stormy-mountain-69843.herokuapp.com/api/kursi'
      );
      setKursi(dataIsi.data);
      console.log(dataIsi.data);
    } catch (err) {
      console.error(err.message);
    }
  };
  const setnamakursi = (nama) => {
    setNomorkursi(nama);
  };
  useEffect(() => {
    getKursi();
  }, []);
  const dataKursi = [
    {
      nama: '1V',
    },
    {
      nama: '2V',
    },
    {
      nama: '3V',
    },
    {
      nama: '4V',
    },
    {
      nama: '5V',
    },
    {
      nama: '6V',
    },
  ];
  return (
    <View style={styles.container}>
      <View
        style={{
          flexDirection: 'row',
          justifyContent: 'space-between',
          padding: 20,
        }}>
        <TouchableOpacity onPress={() => navigation.navigate('Layout2')}>
          <View>
            <Feather name="arrow-left" size={24} color="white" />
          </View>
        </TouchableOpacity>
        <View>
          <Text style={{ color: 'white', marginRight: 80 }}>
            Sektor Premium
          </Text>
        </View>
      </View>
      <FlatList
        data={kursi}
        numColumns={7}
        renderItem={({ item }) => (
          <>
            <View
              style={{
                flexDirection: 'row',
                justifyContent: 'space-between',
                marginLeft: 10,
              }}>
              <TouchableOpacity
                onPress={() => {
                  setnamakursi(item.nama);
                }}>
                <View
                  style={{
                    marginTop: 10,
                    height: 30,
                    width: 30,
                    marginLeft: 5,
                    borderRadius: 10,
                    backgroundColor: 'white',
                    fontSize: 18,
                    fontWeight: 'bold',
                    textAlign: 'center',
                  }}>
                  {item.nama}
                </View>
              </TouchableOpacity>
            </View>
          </>
        )}
      />

      <View style={styles.paragraph}>
        <View
          style={{
            flexDirection: 'row',
            justifyContent: 'space-between',
            marginLeft: 10,
            marginRight: 20,
            padding: 20,
          }}>
          <View
            style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
            <View
              style={{
                height: 10,
                width: 10,
                marginRight: 10,
                borderRadius: 5,
                backgroundColor: 'grey',
              }}></View>
            <Text style={{ fontSize: 10, marginRight: 10, fontWeight: 'bold' }}>
              Kursi gratis
            </Text>
          </View>
          <View
            style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
            <View
              style={{
                height: 10,
                width: 10,
                marginRight: 10,
                borderRadius: 5,
                backgroundColor: '#494ce6',
              }}></View>
            <Text style={{ fontSize: 10, fontWeight: 'bold' }}>
              Kursi terisi
            </Text>
          </View>
          <View
            style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
            <View
              style={{
                height: 10,
                width: 10,
                marginRight: 10,
                borderRadius: 5,
                backgroundColor: '#f5ac36',
              }}></View>
            <Text style={{ fontSize: 10, fontWeight: 'bold' }}>
              Kursi premium
            </Text>
          </View>
        </View>
        <View
          style={{
            flexDirection: 'row',
            marginLeft: 30,
            marginRight: 30,
          }}>
          <Text>tempat yang dipilih : </Text>
        </View>
        <View
          style={{
            flexDirection: 'row',
            justifyContent: 'space-between',
            marginLeft: 30,
            marginRight: 30,
          }}>
          <Text
            style={{
              fontWeight: 'bold',
            }}>
            Kursi {nomorkursi}
          </Text>
          <Text>Baris</Text>
          <Text>Sektor</Text>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingTop: Constants.statusBarHeight,
    backgroundColor: '#2a0c59',
    padding: 8,
  },
  paragraph: {
    marginTop: 10,
    height: 140,
    width: 315,
    marginLeft: 5,
    borderRadius: 20,
    backgroundColor: 'white',
    margin: 24,
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
  },
});
