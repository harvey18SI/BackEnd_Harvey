import React, { useState, useEffect } from 'react';
import { Text, View, StyleSheet, Image, TouchableOpacity } from 'react-native';
import Constants from 'expo-constants';
import axios from 'axios';

// You can import from local files
import AssetsExample from './AssetExample';

// or any pure javascript modules available in npm
import { Card } from 'react-native-paper';
import {
  Ionicons,
  Feather,
  AntDesign,
  FontAwesome,
  SimpleLineIcons,
  MaterialIcons,
} from '@expo/vector-icons';

export default function Layout2({ route, navigation }) {
  const dataList = route.params;
  const [total, setTotal] = useState(0);
  const [hasil, setHasil] = useState(0);
  const penjumlahan = () => {
    const tampung = total + 1;
    setTotal(tampung);
    setHasil(tampung * 40000);
  };
  const pengurangan = () => {
    const tampung = total - 1;
    setTotal(tampung);
    setHasil(tampung * 40000);
  };
  const [kategori, setKategori] = useState([]);
  const getKategori = async () => {
    try {
      const dataIsi = await axios.get(
        'https://stormy-mountain-69843.herokuapp.com/api/tiket'
      );
      setKategori(dataIsi.data);
      console.log(dataIsi.data);
    } catch (err) {
      console.error(err.message);
    }
  };
  useEffect(() => {
    getKategori();
  }, []);

  const dataPayment = [
    {
    nama : 'Paypal'
  }]
  return (
    <View style={styles.container}>
      <TouchableOpacity onPress={() => navigation.navigate('Layout1')}>
        <View
          style={{
            flexDirection: 'row',
            justifyContent: 'space-between',
            padding: 20,
          }}>
          <View>
            <AntDesign name="arrowleft" size={24} color="black" />
          </View>
        </View>
      </TouchableOpacity>
      <View
        style={{
          justifyContent: 'space-between',
          padding: 20,
        }}>
        <View>
          <View style={{ color: 'white' }}>
            <Image
              source={{
                uri:
                  'https://stormy-mountain-69843.herokuapp.com/gambar/' +
                  dataList.foto,
              }}
              style={{
                height: 100,
                width: 100,
                marginLeft: 20,
                borderRadius: 20,
              }}
            />
          </View>
          <Text style={styles.judul}>{dataList.nama}</Text>
          <Text style={styles.judul}>{dataList.subJudul}</Text>
          <Text style={styles.judul1}>{dataList.tanggal}</Text>
        </View>
      </View>

      <View style={styles.card}>
        <View
          style={{
            flexDirection: 'row',
            justifyContent: 'space-between',
            padding: 9,
          }}>
          <View>
            <FontAwesome name="diamond" size={13} color="black" />
          </View>
          <View>
            <Text style={styles.text1}>{dataList.id_kategori.nama}: Rp 40.000</Text>
          </View>

          <View
            style={{
              flexDirection: 'row',
            }}>
            <TouchableOpacity
              onPress={() => {
                pengurangan();
              }}>
              <AntDesign name="minussquare" size={22} color="grey" />
            </TouchableOpacity>
            <Text style={{ fontWeight: 'Bold', marginRight: 15 }}>
              {total} pcs
            </Text>
            <TouchableOpacity
              onPress={() => {
                penjumlahan();
              }}>
              <MaterialIcons name="add-box" size={24} color="grey" />
            </TouchableOpacity>
          </View>
        </View>

        <View
          style={{
            flexDirection: 'row',
            justifyContent: 'space-between',
            padding: 10,
            marginTop: 30,
          }}>
          <Text style={{ fontWeight: 'Bold' }}>Total :</Text>
          <Text style={{ fontWeight: 'Bold', marginRight: 10, fontSize: 25 }}>
            Rp {hasil}
          </Text>
        </View>
        <View
          style={{
            flexDirection: 'row',
            justifyContent: 'space-between',
            padding: 10,
            marginTop: 8,
          }}>
          <Text style={{ fontWeight: 'bold' }}>Cara Pembayaran</Text>
        </View>
        <TouchableOpacity onPress={() => navigation.navigate('Layout3')}>
          <View
            style={{
              height: 50,
              width: 290,
              backgroundColor: 'orange',
              borderColor: 'grey',
              borderRadius: 20,
              justifyContent: 'space-between',
              alignItems: 'left',
              marginTop: 2,
              flexDirection: 'row',
            }}>
            <View>
              <Image
                style={{
                  width: 38,
                  height: 38,
                  marginTop: 6,
                  marginLeft: 20,
                }}
                source={{
                  uri:
                    'https://cdn4.iconfinder.com/data/icons/logos-and-brands/512/250_Paypal_logo-512.png',
                }}></Image>
            </View>
            <View>
              <Text
                style={{
                  fontWeight: 'Bold',
                  marginRight: 110,
                  marginTop: 13,
                  fontSize: 15,
                }}>
                {' '}
                Paypal
              </Text>
            </View>
            <View>
              <MaterialIcons
                name="keyboard-arrow-right"
                size={24}
                color="black"
                style={{ marginTop: 12, marginLeft: 1 }}
              />
            </View>
          </View>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingTop: Constants.statusBarHeight,
    backgroundColor: '#FFFFF',
    padding: 8,
  },
  judul: {
    fontSize: 25,
    fontWeight: 'bold',
    marginLeft: 20,
    color: '#3A3C3B',
  },
  judul1: {
    fontSize: 8,
    fontWeight: 'normal',
    marginLeft: 20,
    marginTop: 15,
    color: 'grey',
  },
  text1: {
    fontSize: 13,
    fontWeight: 'bold',
    marginLeft: 7,
    marginRight: 50,
    color: 'black',
  },
  card: {
    padding: 8,
    fontSize: 18,
    fontWeight: 'bold',
    marginTop: 10,
    height: 100,
    borderRadius: 10,
    backgroundColor: '#FFFFF',
  },
});
