import React, { useState, useEffect } from 'react';
import {
  Text,
  View,
  StyleSheet,
  Image,
  FlatList,
  TouchableOpacity,
} from 'react-native';
import Constants from 'expo-constants';
import axios from 'axios';

// You can import from local files
import AssetsExample from './AssetExample';

// or any pure javascript modules available in npm
import { Card } from 'react-native-paper';
import {
  Ionicons,
  Feather,
  MaterialCommunityIcons,
  Entypo,
} from '@expo/vector-icons';

export default function Layout1({ navigation }) {
  const [tiket, setTiket] = useState([]);
  const getTiket = async () => {
    try {
      const dataIsi = await axios.get(
        'https://stormy-mountain-69843.herokuapp.com/api/tiket'
      );
      setTiket(dataIsi.data);
      console.log(dataIsi.data);
    } catch (err) {
      console.error(err.message);
    }
  };
  const dataMusik = [
    {
      foto: 'https://cf.shopee.co.id/file/5f943cdbb22e51b69ad103bab9afdc16',
      genre: 'JAZZ',
      judul: 'DO Music',
      subJudul: 'Festival Musik',
      tanggalJam: '30 januari 2021 18:00',
    },
    {
      foto: 'https://cf.shopee.co.id/file/9cf6f1458df0665533ad0643808cd39d',
      genre: 'MUSIC',
      judul: 'Louis Tomlinson',
      subJudul: 'Always You',
      tanggalJam: '12 Juni 2021 17:00',
    },
    {
      foto:
        'https://mopt.com.au/wp-content/uploads/2020/03/Lauv_MargaretCourtArena_604x604.jpg',
      genre: 'MUSIC',
      judul: 'Lauv',
      subJudul: "How i'm feeling",
      tanggalJam: '14 September 2021 17:00',
    },
    {
      foto:
        'https://ih1.redbubble.net/image.1068689153.5680/st,small,845x845-pad,1000x1000,f8f8f8.jpg',
      genre: 'KPOP',
      judul: 'BTS',
      subJudul: 'Love Yourself',
      tanggalJam: 'Coming Soon',
    },
  ];
  useEffect(() => {
    getTiket();
  }, []);

  return (
    <View style={styles.container}>
      <View
        style={{
          flexDirection: 'row',
          justifyContent: 'space-between',
          padding: 20,
        }}>
        <View>
          <TouchableOpacity onPress={() => navigation.navigate('')}>
          <Feather name="search" size={24} color="black" />
          </TouchableOpacity>
        </View>

        <View
          style={{
            flexDirection: 'row',
            justifyContent: 'center',
            alignItems: 'center',
          }}>
          <TouchableOpacity onPress={() => navigation.navigate('')}>
          <Ionicons name="notifications-outline" size={24} color="black" />
          </TouchableOpacity>
          <TouchableOpacity onPress={() => navigation.navigate('')}>
          <Image
            style={{
              width: 30,
              height: 30,
              borderRadius: 20,
            }}
            source={{
              uri:
                'https://static.wikia.nocookie.net/mobile-legends/images/8/89/Guinevere.png/revision/latest?cb=20190304120629',
            }}
          />
          </TouchableOpacity>
        </View>
        
      </View>

      <View
        style={{
          flexDirection: 'row',
          justifyContent: 'space-between',
          padding: 20,
        }}>
        <View>
          <Text
            style={{
              fontWeight: 'normal',
              fontSize: 30,
            }}>
            Halo
          </Text>
          <Text
            style={{
              fontWeight: 'bold',
              fontSize: 30,
            }}>
            Konser!
          </Text>
        </View>

        <View
          style={{
            flexDirection: 'row',
            justifyContent: 'center',
            alignItems: 'center',
          }}>
          <Text
            style={{
              flexDirection: 'row',
              justifyContent: 'center',
              marginRight: 5,
              fontWeight: 'bold',
              alignItems: 'center',
            }}>
            Filters
          </Text>
          <Ionicons name="list" size={20} color="black" />
        </View>
      </View>

      <View
        style={{
          flexDirection: 'row',
          justifyContent: 'space-between',
          padding: 20,
        }}>
        <Text
          style={{
            flexDirection: 'row',
            justifyContent: 'center',
            marginRight: 5,
            fontWeight: 'bold',
            alignItems: 'center',
          }}>
          Konser yang baru ditambahkan
        </Text>
      </View>
      <FlatList
        data={tiket}
        renderItem={({ item }) => (
          <>
            <TouchableOpacity
              onPress={() => navigation.navigate('Layout2', item)}>
              <View
                style={{
                  flexDirection: 'row',
                  justifyContent: 'space-between',
                }}>
                <View style={{ marginTop: 10, color: 'white' }}>
                  <Image
                    source={{
                      uri:
                        'https://stormy-mountain-69843.herokuapp.com/gambar/' +
                        item.foto
                    }}
                    style={{
                      height: 90,
                      width: 90,
                      marginLeft: 20,
                      borderRadius: 20,
                    }}
                  />
                </View>
                <View style={{ marginLeft: 10, width: 130 }}>
                  <Text
                    style={{
                      marginTop: 8,
                      color: '#9E31E1',
                      fontWeight: 'bold',
                    }}>
                    {item.genre}
                  </Text>
                  <Text
                    style={{
                      marginTop: 8,
                      color: 'Black',
                      fontWeight: 'bold',
                      fontSize: 10,
                    }}>
                    {item.nama}
                  </Text>
                  <Text
                    style={{
                      marginTop: 8,
                      color: 'Black',
                      fontWeight: 'bold',
                      fontSize: 10,
                    }}>
                    {item.id_kategori.nama}
                  </Text>
                  <Text style={{ marginTop: 8, color: 'Black', fontSize: 9 }}>
                    {item.tanggal}, {item.jam}
                  </Text>
                </View>
                <View style={{ marginLeft: 20 }}>
                  <Ionicons
                    name="arrow-forward"
                    size={24}
                    color="black"
                    style={{ marginTop: 40, marginRight: 30 }}
                  />
                </View>
              </View>
            </TouchableOpacity>
          </>
        )}
      />

      <View
        style={{
          flexDirection: 'row',
          justifyContent: 'center',
          alignItems: 'center',
          marginTop: 40,
        }}>
        <TouchableOpacity onPress={() => navigation.navigate('Layout1')}>
        <View
          style={{
            height: 40,
            width: 70,
            borderRadius: 10,
            backgroundColor: 'white',
          }}>
          <Feather
            name="star"
            size={24}
            color="grey"
            style={{ marginTop: 8, marginLeft: 23 }}
          />
        </View>
        </TouchableOpacity>
        <TouchableOpacity onPress={() => navigation.navigate('Layout1')}>
          <View
            style={{
              height: 50,
              width: 80,
              marginLeft: 5,
              borderRadius: 10,
              backgroundColor: 'orange',
            }}>
            <Ionicons
              name="home-outline"
              size={24}
              color="white"
              style={{ marginTop: 12, marginLeft: 28 }}
            />
          </View>
        </TouchableOpacity>
        <TouchableOpacity onPress={() => navigation.navigate('Layout1')}>
          <View
            style={{
              height: 40,
              width: 70,
              marginLeft: 5,
              borderRadius: 10,
              backgroundColor: 'white',
            }}>
            <Entypo
              name="ticket"
              size={24}
              color="grey"
              style={{ marginTop: 8, marginLeft: 23 }}
            />
          </View>
        </TouchableOpacity>
      </View>

      <View></View>

      <View style={styles.paragraph}></View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingTop: Constants.statusBarHeight,
    backgroundColor: 'white',
    padding: 8,
  },
  paragraph: {
    margin: 24,
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
  },
});
